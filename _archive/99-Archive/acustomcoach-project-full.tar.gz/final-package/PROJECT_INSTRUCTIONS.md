# Cowork Project Instructions

## Who I Am
Bobby Long. Navy veteran (MC1, 8+ years), multimedia production specialist. Building Speed of Now Productions. Finishing MBA in Strategic Marketing. Comfortable with Next.js, React, Tailwind, Vercel, GitHub. I build production apps — treat me like a fellow builder, not a student.

## How I Work
- Be direct. Short answers for simple questions.
- Skip basics. Give me actionable next steps.
- If I need to do something, give me the exact steps — no fluff.
- I move fast. Three full-stack apps in three days fast. Don't pad timelines.
- Flag gotchas before they bite me, especially on git and deployment.

## "Sidebar" Protocol
When I say "sidebar" — pause the current task completely. Address the sidebar topic fully. When I say "back", resume exactly where we left off.

## On Every New Session
1. Read `CLAUDE.md` at the project root — it has full project state, design system, architecture, open questions, and rules.
2. Check the current state of `site/` (or the repo root) to see what's built vs. stubbed.
3. Reference `_context/site-recovery.md` for any content decisions.
4. Check `_context/client-answers.md` for the latest confirmed/unconfirmed details.
5. Then pick up wherever I direct you.

## Project: A Custom Coach Website Rebuild
- Rebuilding acustomcoach.com for a Denver/Boulder luxury transportation company (est. 1988)
- Owner: John Hafer (my uncle). Mom runs his books and is the go-between.
- Old site went down when hosting provider folded. All content recovered.
- Source of truth: `_context/site-recovery.md`
- Tech: Next.js 16, TypeScript, Tailwind v4, Vercel
- Booking: FASTTRAK Cloud (already in use — link/embed their portal, don't rebuild)
- Design: LOCKED. Dark premium aesthetic. See CLAUDE.md for full design system. Don't deviate without asking.

## Project: Speed of Now Productions (My Business)
- Productizing the A Custom Coach project into a repeatable SMB service offering
- Target market: Established local businesses with outdated/broken web presence
- `_business/` folder tracks this work
- Build the playbook and case study as the John project progresses

## Always Ask Before
- Finalizing any business details (phone, address, hours, staff names)
- Choosing a reservation/booking system
- Making major structural decisions that deviate from the 6-page layout
- Changing anything in the approved design system

## File Conventions
- `_context/` = reference material (read, don't modify unless I say to)
- `_business/` = Speed of Now business planning docs
- `deliverables/` = client-facing output (write for a 60-year-old, no jargon)
- `site/` = the codebase (proper git workflow)
- `CLAUDE.md` = project state (update when milestones complete)
